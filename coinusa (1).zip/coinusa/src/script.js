// Example: Handling login form submission

// Get the login form elements
const loginForm = document.getElementById("loginForm");
const loginPhoneInput = document.getElementById("loginPhone");
const loginPasswordInput = document.getElementById("loginPassword");

// Handle login form submission
loginForm.addEventListener("submit", function (e) {
  e.preventDefault();

  // Get values from the form
  const phoneNumber = loginPhoneInput.value.trim();
  const password = loginPasswordInput.value.trim();

  // Basic validation
  if (!phoneNumber || !password) {
    alert("Please fill in all fields.");
    return;
  }

  // Example login credentials validation (for demonstration)
  if (phoneNumber === "+2347034619642" && password === "ashleycoleman33") {
    // Successful login - Redirect to the dashboard or home page
    alert("Login successful!");
    window.location.href = "/dashboard.html"; // Change this to your actual dashboard URL
  } else {
    // Invalid login credentials
    alert("Invalid phone number or password. Please try again.");
  }
});

// ---------- BASIC USER + HOLDINGS ----------
const USER_NAME = "Ashley Coleman"; // change to your account name if you like

// Holdings in USD + official CoinGecko logo URLs
const holdings = {
  BTC: {
    symbol: "BTC",
    name: "Bitcoin",
    usd: 31775.11,
    icon: "https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1547033579"
  },
  ETH: {
    symbol: "ETH",
    name: "Ethereum",
    usd: 4032.0,
    icon: "https://assets.coingecko.com/coins/images/279/large/ethereum.png?1595348880"
  },
  SOL: {
    symbol: "SOL",
    name: "Solana",
    usd: 7000.0,
    icon: "https://assets.coingecko.com/coins/images/4128/large/solana.png?1640133422"
  }
};

function formatUsd(v) {
  return `$${v.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
}

function formatBtc(v) {
  return `${v.toFixed(8)} BTC`;
}

// Set username in the correct element


// Portfolio totals (fixed holdings from your spec)
const totalPortfolio = Object.values(holdings).reduce(
  (sum, a) => sum + a.usd,
  0
);

document.getElementById("totalPortfolio").textContent = formatUsd(totalPortfolio);
document.getElementById("sendTotalPortfolio").textContent = formatUsd(totalPortfolio);

// Show placeholders for BTC conversion until we load live BTC price
document.getElementById("totalPortfolioBtc").textContent = "Loading…";
document.getElementById("sendTotalPortfolioBtc").textContent = "Loading…";

// Populate holdings list with real logos
const holdingsList = document.getElementById("holdingsList");
Object.values(holdings).forEach((asset) => {
  const card = document.createElement("div");
  card.className = "holding-card";
  card.innerHTML = `
    <div class="holding-left">
      <div class="asset-icon">
        <img src="${asset.icon}" alt="${asset.symbol} logo" />
      </div>
      <div>
        <div class="asset-name">${asset.symbol}</div>
        <div class="asset-sub">${asset.name}</div>
      </div>
    </div>
    <div class="holding-right">
      <div class="holding-amount">${formatUsd(asset.usd)}</div>
      <div class="holding-fiat">Approx. portfolio share</div>
    </div>
  `;
  holdingsList.appendChild(card);
});

// ---------- TABS ----------
const tabs = document.querySelectorAll(".action-tabs .tab");
const views = document.querySelectorAll(".view");

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    tabs.forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");

    const target = tab.dataset.section;
    views.forEach((view) => {
      view.classList.toggle("active", view.id === target);
    });
  });
});

// ---------- SEND FORM ----------
const sendAssetSelect = document.getElementById("sendAsset");
const availableSpan = document.getElementById("availableForAsset");
const sendAmountInput = document.getElementById("sendAmount");
const percentageButtons = document.querySelectorAll(".pill-btn");

function updateAvailable() {
  const assetKey = sendAssetSelect.value;
  const asset = holdings[assetKey];
  availableSpan.textContent = formatUsd(asset.usd);
}
updateAvailable();

sendAssetSelect.addEventListener("change", updateAvailable);

percentageButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    const percent = Number(btn.dataset.percent);
    const assetKey = sendAssetSelect.value;
    const asset = holdings[assetKey];
    const amount = (asset.usd * percent) / 100;
    sendAmountInput.value = amount.toFixed(2);
  });
});

const sendForm = document.getElementById("sendForm");
const gasModal = document.getElementById("gasModal");
const closeModalBtn = document.getElementById("closeModal");

sendForm.addEventListener("submit", (e) => {
  e.preventDefault();
  // Demo only: show safe "insufficient gas" modal instead of sending anything
  gasModal.classList.remove("hidden");
});

closeModalBtn.addEventListener("click", () => {
  gasModal.classList.add("hidden");
});

// ---------- RECEIVE: COPY ADDRESS ----------
document.querySelectorAll(".copy-btn").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const address = btn.dataset.address;
    try {
      await navigator.clipboard.writeText(address);
      btn.textContent = "Copied!";
      setTimeout(() => {
        btn.textContent = "Copy";
      }, 1200);
    } catch (err) {
      console.error("Clipboard error:", err);
      btn.textContent = "Error";
      setTimeout(() => {
        btn.textContent = "Copy";
      }, 1200);
    }
  });
});

// ---------- LIVE MARKET DATA (TOP 100 COINS) ----------
const MARKET_API_URL =
  "https://api.coingecko.com/api/v3/coins/markets" +
  "?vs_currency=usd&order=market_cap_desc&per_page=100&page=1" +
  "&sparkline=false&price_change_percentage=24h";

const marketsStatus = document.getElementById("marketsStatus");
const marketsBody = document.getElementById("marketsBody");
let marketChart = null;

async function loadMarketData() {
  try {
    marketsStatus.textContent = "Loading live market data…";

    const res = await fetch(MARKET_API_URL);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const coins = await res.json();

    // 1) Update table + BTC portfolio conversion first
    renderMarketsTable(coins);
    updatePortfolioBtcFromMarket(coins);

    // 2) Try to render chart but don't let it break BTC update
    try {
      renderMarketsChart(coins);
    } catch (chartErr) {
      console.error("Chart render error:", chartErr);
    }

    marketsStatus.textContent = "Top 100 coins by market cap (live).";
  } catch (err) {
    console.error("Error loading market data:", err);
    marketsStatus.textContent =
      "Unable to load live market data right now. Please try again later.";
    document.getElementById("totalPortfolioBtc").textContent = "N/A";
    document.getElementById("sendTotalPortfolioBtc").textContent = "N/A";
  }
}

// Use live BTC price (from CoinGecko) to convert your USD holdings -> BTC
function updatePortfolioBtcFromMarket(coins) {
  const btcCoin = coins.find(
    (c) =>
      (c.symbol && c.symbol.toLowerCase() === "btc") || c.id === "bitcoin"
  );
  if (!btcCoin || !btcCoin.current_price) {
    return;
  }

  const btcPriceUsd = btcCoin.current_price;
  const totalBtc = totalPortfolio / btcPriceUsd;
  const formatted = formatBtc(totalBtc);

  document.getElementById("totalPortfolioBtc").textContent = formatted;
  document.getElementById("sendTotalPortfolioBtc").textContent = formatted;
}

function renderMarketsTable(coins) {
  marketsBody.innerHTML = "";
  coins.forEach((coin) => {
    const tr = document.createElement("tr");

    const priceChange = coin.price_change_percentage_24h ?? 0;
    const changeClass = priceChange >= 0 ? "positive" : "negative";

    tr.innerHTML = `
      <td>${coin.market_cap_rank ?? "-"}</td>
      <td class="market-coin">
        <img src="${coin.image}" alt="${coin.symbol}" class="coin-icon" />
        <div>
          <div class="asset-name">${coin.name}</div>
          <div class="asset-sub">${coin.symbol.toUpperCase()}</div>
        </div>
      </td>
      <td>${formatUsd(coin.current_price)}</td>
      <td class="${changeClass}">
        ${priceChange.toFixed(2)}%
      </td>
      <td>${formatUsd(coin.market_cap)}</td>
    `;

    marketsBody.appendChild(tr);
  });
}

function renderMarketsChart(coins) {
  const ctx = document.getElementById("marketChart").getContext("2d");
  const labels = coins.map((c) => c.symbol.toUpperCase());
  const caps = coins.map((c) => c.market_cap);

  if (marketChart) {
    marketChart.data.labels = labels;
    marketChart.data.datasets[0].data = caps;
    marketChart.update();
    return;
  }

  marketChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Market Cap (USD)",
          data: caps
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => " " + formatUsd(ctx.parsed.y)
          }
        }
      },
      scales: {
        x: {
          ticks: { display: false }
        },
        y: {
          ticks: {
            callback: (value) => {
              if (value >= 1_000_000_000_000)
                return "$" + (value / 1_000_000_000_000).toFixed(1) + "T";
              if (value >= 1_000_000_000)
                return "$" + (value / 1_000_000_000).toFixed(1) + "B";
              if (value >= 1_000_000)
                return "$" + (value / 1_000_000).toFixed(1) + "M";
              return "$" + value.toLocaleString();
            }
          }
        }
      }
    }
  });
}

// Load data now and refresh every 60 seconds
loadMarketData();
setInterval(loadMarketData, 60000);
